package egovframework.dbTest.service;

public interface dbTestService {

	dbTestVO selectTableData() throws Exception;
}

